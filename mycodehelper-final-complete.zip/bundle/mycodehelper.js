/**
 * MyCodeHelper - Local AI & Hugging Face Edition
 * A fully functional AI-powered code assistant
 * 
 * Windows Compatible Version
 */

import { createInterface } from 'readline';

// Simple fetch implementation for Node.js environments that don't have it
const fetch = globalThis.fetch || (await import('undici')).fetch;

// Configuration
const CONFIG = {
  LOCAL_AI: {
    apiKey: process.env.LOCAL_AI_API_KEY || 'local-key',
    baseUrl: process.env.LOCAL_AI_BASE_URL || 'http://localhost:8080',
    model: process.env.LOCAL_AI_MODEL || 'llama-3.1-8b'
  },
  HUGGING_FACE: {
    apiKey: process.env.HUGGING_FACE_API_KEY,
    model: process.env.HUGGING_FACE_MODEL || 'microsoft/DialoGPT-large'
  },
  maxTokens: parseInt(process.env.MYCODEHELPER_MAX_TOKENS || '4096'),
  temperature: parseFloat(process.env.MYCODEHELPER_TEMPERATURE || '0.7'),
  defaultProvider: process.env.MYCODEHELPER_DEFAULT_PROVIDER || 'local-ai-api-key'
};

// AI Client implementations
class LocalAIClient {
  constructor(config) {
    this.config = config;
  }

  async generateContent(message) {
    try {
      const response = await fetch(`${this.config.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        body: JSON.stringify({
          model: this.config.model,
          messages: [{ role: 'user', content: message }],
          temperature: CONFIG.temperature,
          max_tokens: CONFIG.maxTokens
        })
      });

      if (!response.ok) {
        throw new Error(`Local AI API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      return data.choices?.[0]?.message?.content || 'No response from Local AI';
    } catch (error) {
      return `Error: ${error.message}`;
    }
  }
}

class HuggingFaceClient {
  constructor(config) {
    this.config = config;
  }

  async generateContent(message) {
    try {
      const response = await fetch(`https://api-inference.huggingface.co/models/${this.config.model}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.apiKey}`
        },
        body: JSON.stringify({
          inputs: message,
          parameters: {
            temperature: CONFIG.temperature,
            max_new_tokens: CONFIG.maxTokens,
            return_full_text: false
          },
          options: {
            wait_for_model: true
          }
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Hugging Face API error: ${response.status} ${errorText}`);
      }

      const data = await response.json();
      return Array.isArray(data) ? data[0]?.generated_text || 'No response from Hugging Face' : data.generated_text || 'No response';
    } catch (error) {
      return `Error: ${error.message}`;
    }
  }
}

// Main Application
class MyCodeHelper {
  constructor() {
    this.conversation = [];
    this.client = null;
    this.providerType = null;
  }

  async initialize() {
    console.log('🚀 MyCodeHelper v0.1.13 - Local AI & Hugging Face Edition');
    console.log('============================================================');
    console.log('');

    // Determine which provider to use
    if (CONFIG.defaultProvider === 'local-ai-api-key' && CONFIG.LOCAL_AI.apiKey) {
      this.client = new LocalAIClient(CONFIG.LOCAL_AI);
      this.providerType = 'Local AI';
      console.log(`✅ Using Local AI: ${CONFIG.LOCAL_AI.model} at ${CONFIG.LOCAL_AI.baseUrl}`);
    } else if (CONFIG.defaultProvider === 'hugging-face-api-key' && CONFIG.HUGGING_FACE.apiKey) {
      this.client = new HuggingFaceClient(CONFIG.HUGGING_FACE);
      this.providerType = 'Hugging Face';
      console.log(`✅ Using Hugging Face: ${CONFIG.HUGGING_FACE.model}`);
    } else if (CONFIG.HUGGING_FACE.apiKey) {
      this.client = new HuggingFaceClient(CONFIG.HUGGING_FACE);
      this.providerType = 'Hugging Face';
      console.log(`✅ Using Hugging Face: ${CONFIG.HUGGING_FACE.model}`);
    } else if (CONFIG.LOCAL_AI.apiKey) {
      this.client = new LocalAIClient(CONFIG.LOCAL_AI);
      this.providerType = 'Local AI';
      console.log(`✅ Using Local AI: ${CONFIG.LOCAL_AI.model} at ${CONFIG.LOCAL_AI.baseUrl}`);
    } else {
      console.log('❌ No AI provider configured!');
      console.log('');
      console.log('Please set environment variables:');
      console.log('  For Local AI:');
      console.log('    export LOCAL_AI_API_KEY="your-api-key"');
      console.log('    export LOCAL_AI_BASE_URL="http://localhost:8080"');
      console.log('');
      console.log('  For Hugging Face:');
      console.log('    export HUGGING_FACE_API_KEY="hf_your-token"');
      console.log('');
      console.log('  Or run the setup script: ./setup-env.sh');
      process.exit(1);
    }

    console.log('');
    console.log('💡 Ready! Ask me anything about coding.');
    console.log('💡 Type "help" for commands, "exit" to quit.');
    console.log('');
  }

  async chat() {
    const rl = createInterface({
      input: process.stdin,
      output: process.stdout
    });

    const askQuestion = () => {
      return new Promise((resolve) => {
        rl.question('👤 You: ', resolve);
      });
    };

    while (true) {
      try {
        const userInput = await askQuestion();
        
        if (userInput.toLowerCase() === 'exit' || userInput.toLowerCase() === 'quit') {
          console.log('👋 Goodbye!');
          break;
        }

        if (userInput.toLowerCase() === 'help') {
          this.showHelp();
          continue;
        }

        if (userInput.toLowerCase() === 'clear') {
          this.conversation = [];
          console.log('🧹 Conversation cleared.');
          continue;
        }

        if (userInput.toLowerCase() === 'status') {
          this.showStatus();
          continue;
        }

        if (userInput.trim() === '') {
          continue;
        }

        // Add user message to conversation
        this.conversation.push({ role: 'user', content: userInput });

        process.stdout.write(`🤖 ${this.providerType}: `);
        
        // Get AI response
        const response = await this.client.generateContent(userInput);
        console.log(response);
        console.log('');

        // Add AI response to conversation
        this.conversation.push({ role: 'assistant', content: response });

      } catch (error) {
        console.log(`❌ Error: ${error.message}`);
        console.log('');
      }
    }

    rl.close();
  }

  showHelp() {
    console.log('📖 MyCodeHelper Commands:');
    console.log('========================');
    console.log('  help    - Show this help message');
    console.log('  clear   - Clear conversation history');
    console.log('  status  - Show current configuration');
    console.log('  exit    - Exit the application');
    console.log('');
    console.log('💡 Examples:');
    console.log('  "How do I create a React component?"');
    console.log('  "Explain async/await in JavaScript"');
    console.log('  "Write a Python function to sort a list"');
    console.log('');
  }

  showStatus() {
    console.log('⚙️ MyCodeHelper Status:');
    console.log('======================');
    console.log(`Provider: ${this.providerType}`);
    console.log(`Model: ${this.client.config.model}`);
    console.log(`Conversation length: ${this.conversation.length} messages`);
    console.log(`Temperature: ${CONFIG.temperature}`);
    console.log(`Max tokens: ${CONFIG.maxTokens}`);
    console.log('');
  }
}

// Start the application
async function main() {
  const app = new MyCodeHelper();
  await app.initialize();
  await app.chat();
}

// Handle process termination
process.on('SIGINT', () => {
  console.log('\n👋 Goodbye!');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n👋 Goodbye!');
  process.exit(0);
});

// Run the application
main().catch(error => {
  console.error('💥 Fatal error:', error.message);
  process.exit(1);
});
